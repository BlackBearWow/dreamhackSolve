#! /bin/bash
git clone --branch safari-610.1.8-branch --single-branch --depth 1 https://github.com/WebKit/WebKit.git
cd ./WebKit
patch -p1 < ../patch.diff
./Tools/Scripts/build-webkit --jsc-only --release