import os
import sys
import tempfile

def print_str(s):
    sys.stdout.write(s)
    sys.stdout.flush()

def get_int(msg):
    print_str(msg)
    return int(sys.stdin.readline().strip())

def get_data(msg, length):
    print_str(msg)
    return sys.stdin.buffer.read(length)

filesize = get_int("Javascript file size : ")
filedata = get_data("Javascript file data : ", filesize)

fd, filepath = tempfile.mkstemp()

with open(fd, 'wb') as f:
    f.write(filedata)
    
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.system(f"LD_PRELOAD=./libJavaScriptCore.so.1.0.0 ./jsc {filepath}")
os.unlink(filepath)