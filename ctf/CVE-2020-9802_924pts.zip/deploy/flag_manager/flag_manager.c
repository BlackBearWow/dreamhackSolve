#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char* argv[]){
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  srand(time(NULL));

  puts("Hello,");
  puts("do you have \"REAL\" shell ???");
  puts("show me your shell !");


  int a = rand()%100;
  int b = rand()%100;
  int userinp;
  printf("Question : %d + %d = ?\n", a, b);
  printf("Answer : ");
  scanf("%d", &userinp);

  if( (a+b) == userinp){
    FILE* fp = fopen("/flag.txt", "rb");
    if(!fp) {
      printf("ERROR ! contact admin.\n");
      return 1;
    }
    
    char flag[100];
    memset(flag, 0, sizeof(flag));
    if(!fgets(flag, 100, fp)) {
      printf("ERROR ! contact admin.\n");
      return 1;
    }

    printf("FLAG: %s\n", flag);
    fclose(fp);
  }

  return 0;
}